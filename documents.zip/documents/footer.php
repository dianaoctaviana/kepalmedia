<style type="text/css">
	#footer{
		position: absolute;
		height: 50px;
		line-height: 50px;
		background-color: #fe7f9c;
		color: #fff;
		bottom: 0;
		width: 100%;
	}
</style>


<div id="footer">
	<center>KepalMedia
</div>