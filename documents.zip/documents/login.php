<?php
session_start();

include 'koneksi.php';

?>

<!DOCTYPE html>
<html>
<head>
	<title>KepalMedia</title>
	
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    


    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css"> 

		
		<link rel="stylesheet" href="login/css/menu.css"/>
		<link rel="stylesheet" href="login/css/main.css"/>
		<link rel="stylesheet" href="login/css/bgimg.css"/>
		<link rel="stylesheet" href="login/css/font.css"/>
		<link rel="stylesheet" href="login/css/font-awesome.min.css"/>
		<script type="text/javascript" src="login/js/jquery-1.12.4.min.js"></script>
		<script type="text/javascript" src="login/js/main.js"></script>
	</head>
  

    <style type="text/css">
    	body{
    background-image : url('aa.jpeg');			
	background-repeat: no-repeat;
	background-size: 100%;
	background-color: grey;
}
		table{
			border: 1px;
			background-color: 
		}
		.container {
  width: 100%;
  padding-right: 0px;
  padding-left: 0px;
  margin-right: auto;
  margin-left: auto; }
  @media (min-width: 576px) {
    .container {
      max-width: 540px; } }
  @media (min-width: 768px) {
    .container {
      max-width: 720px; } }
  @media (min-width: 992px) {
    .container {
      max-width: 960px; } }
  @media (min-width: 1200px) {
    .container {
      max-width: 1140px; } }
    	#login-form {
    		padding-top: 100px;
    	}

    </style>

</head>
<body>

<?php include 'menu.php'; ?>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>

	

    <div class="login-form-container" id="login-form">
    	<br>
		<div class="login-form-content">
			<form method="post" action="" class="login-form">
				<h3>Login</h3>
				<div class="input-container">
					<i class="fa fa-user"></i>
					<input type="text" class="input" name="username" placeholder="Username"/>
				</div>
				<div class="input-container">
					<i class="fa fa-lock"></i>
					<input type="password"  id="login-password" class="input" name="password" placeholder="Password"/>
					<i id="show-password" class="fa fa-eye"></i>
				</div>
				<input type="submit" name="login" value="Login" class="button" style="background-color: #fe7f9c;" />
				<a href="daftar.php" class="register">Register</a>
			</form>
			
		</div>

	</div>
	<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		
		<br>
		<br>



	<?php

	if (isset($_POST["login"])) 
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		  $salt = "TWP8G8O3AosvQpgc";
    $hashedPassword = hash('sha256', $password . $salt);
		  


		$ambil = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username' AND password='$hashedPassword'");
	
	if(mysqli_num_rows($ambil)==0){
		echo "<script>alert('Username dan Password tidak valid.'); window.location = 'login.php'</script>";
	}else{
		
			$row=mysqli_fetch_assoc($ambil);

			$_SESSION["user"] = $row;
			$_SESSION['role']=$row['role'];
			

			if ($row['role']==1) {
			 echo "<script>alert('Selamat datang $username'); window.location = 'admin/index.php'</script>";	
		}
		if ($row['role']==2) {
			 echo "<script>alert('Selamat datang $username'); window.location = 'index.php'</script>";
	}else{
		 echo "<script>alert('Username dan Password tidak valid.'); window.location = 'login.php'</script>";
	}
}
}
	?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>	<br>
	<br>
	<br>
	<footer class="py-7 navbar-dark">
      <div class="container">
        <p class="m-0 text-center text-white">kepalmedia</p>
      </div>
      <!-- /.container -->
    </footer>

</body>
</html>