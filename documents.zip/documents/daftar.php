<?php
    include 'koneksi.php';

    if(isset($_POST["daftar"]))
    {
        // username and password sent from Form
    $email= mysqli_real_escape_string($koneksi,$_POST["email"]); 
    $password= mysqli_real_escape_string($koneksi,$_POST["password"]);
    $username= mysqli_real_escape_string($koneksi,$_POST["username"]);
    $nama= mysqli_real_escape_string($koneksi,$_POST["nama"]);
    $telepon= mysqli_real_escape_string($koneksi,$_POST["telepon"]);
    $alamat= mysqli_real_escape_string($koneksi,$_POST["alamat"]);
    
    $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
    if(preg_match($regex, $email))
{  
    $activation=md5($email.time()); // Encrypted email+timestamp
    $salt = "TWP8G8O3AosvQpgc";
    $hashedPassword = hash('sha256', $password . $salt); // Encrypted password

    $count=$koneksi->query("SELECT id_user FROM user WHERE email=$email");
    if(mysqli_num_rows($count) < 1)
    {

    $koneksi->query("INSERT INTO user (username, email, password, nama_user, nomor_telepon, alamat, activation) 
    VALUES('$username','$email','$hashedPassword','$nama','$telepon','$alamat', '$activation')");
    
    include 'smtp/Send_Mail.php';
    $to=$email;
    $subject="Email verification";
    $body='Hi, <br/> <br/> We need to make sure you are human. Please verify your email and get started using your Website account. <br/> <br/> <a href="'.$base_url.'activation/'.$activation.'">'.$base_url.'activation/'.$activation.'</a>';
    Send_Mail($to,$subject,$body);

    echo "<script>alert('Pendaftaran Sukses, silahkan periksa email anda')</script>";


        }
     else{
        echo "<script>alert('error')</script>";
     }
   
    }
}
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    

    <title>KepalMedia</title>

    <!-- Bootstrap core CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alex+Brush" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css"> 

        <link rel="stylesheet" href="login/css/menu.css"/>
        <link rel="stylesheet" href="login/css/main.css"/>
        <link rel="stylesheet" href="login/css/bgimg.css"/>
        <link rel="stylesheet" href="login/css/font.css"/>
        <link rel="stylesheet" href="login/css/font-awesome.min.css"/>
        <script type="text/javascript" src="login/js/jquery-1.12.4.min.js"></script>
        <script type="text/javascript" src="login/js/main.js"></script>
     

     <style type="text/css">
        body{
                  background-image : url('aa.jpeg');
    background-repeat: no-repeat;
    background-size: 100%;
}
        table{
            border: 1px; 
        }
        #login-form {
            padding-top: 100px;
        }

        button {
            padding: 20px;
            background-color: #fff;

        }
        
    </style>


  </head>

<body>
    <?php include 'menu.php';?>
        <br>
        <br>
        <br>
        <br>
        <br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
    
        <div class="login-form-container" id="login-form">
        <br>
        <div class="login-form-content">
            <div class="login-form-header">
            
                <h3>Register</h3>
            </div>
            <form method="post" action="" class="login-form">
                                <div class="input-container">
                    <i class="fa fa-user"></i>
                    <input type="text" class="input" name="nama" placeholder="Nama" required="" />
                </div>
                <div class="input-container">
                    <i class="fa fa-user"></i>
                    <input type="text" class="input" name="username" placeholder="Username" required="" />
                </div>
                <div class="input-container">
                    <i class="fa fa-lock"></i>
                    <input type="password"  id="login-password" class="input" name="password" placeholder="Password" required="" />
                    <i id="show-password" class="fa fa-eye"></i>
                </div>
                <div class="input-container">
                    <i class="fa fa-envelope"></i>
                    <input type="email" class="input" name="email" placeholder="Email" required="" />
                </div>
                <div class="input-container">
                    <i class="fa fa-phone"></i>
                    <input type="text" class="input" name="telepon" placeholder="Telepon" required="" />
                </div>
                <div class="input-container">
                    <i class="fa fa-map-marker"></i>
                    <input type="text" class="input" name="alamat" placeholder="Alamat" required="" />
                </div>
             
                <div class="button">
                <button class="btn btn-primary btn-lg btn-block" type="submit" name="daftar" value="Daftar">Register</button>
                <button class="btn btn-secondary btn-lg btn-block register" type="submit" href="login.php" >Login</button>
                </div>
            </form>
            
        </div>

    </div>





    
    <br>
    <br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

    
    <footer class="py-7 navbar-dark">
      <div class="container">
        <p class="m-0 text-center text-white">KepalMedia</p>
      </div>
      <!-- /.container -->
    </footer>
</body>
</html>