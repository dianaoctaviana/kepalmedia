<?php 

/*if (!(isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || 
   $_SERVER['HTTPS'] == 1) ||  
   isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&   
   $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https'))
{
   $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
   header('HTTP/1.1 301 Moved Permanently');
   header('Location: ' . $redirect);
   exit();
}*/


include 'koneksi.php';
include 'https.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">


  
  .dropdown-menu{
    background-color: #FE7F9C;
    color: white;
    
    width: 100px;

  }
  .dropdown-item{
    color: white;
  }
  .nav-item{
    color: white;
  }
  .navbar-dark{
    background-color: #FE7F9C;

  }

  .navbar-brand{
    font-family: jokerman;
  }


  

</style>
<link rel="stylesheet" href="fa/css/font-awesome.min.css">

</head>
<body>


  <nav class="navbar fixed-top navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="anj.png" height="50" ></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        
        <ul class="navbar-nav ml-auto">


          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" class="fa fa-user" href="#"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  style="color: white">Account</a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropownPortfolio">

              <?php if (isset($_SESSION["user"])):?>


                <a class="dropdown-item" href="checkout.php">Checkout</a>
                <a class="dropdown-item" href="keranjang.php">Keranjang</a>

                <a class="dropdown-item" href="riwayat.php">Riwayat Belanja</a>
                <a class="dropdown-item" href="logout.php">Logout</a></div>

              <?php else: ?>

               <a class="dropdown-item" href="login.php">Login</a>

               <a class="dropdown-item" href="daftar.php">Daftar</a>

             <?php endif?>

           </li>

         </ul>
       </div>
     </div>
   </div>
 </nav>

</body>
</html>