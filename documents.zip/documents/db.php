<?php

/*$h = 'us-cdbr-iron-east-05.cleardb.net';
$u = 'b9018cb354e472';
$p = '64ce68be';
$db = 'heroku_9bb03835f28e3d5';*/

 
    $connect = new mysqli("localhost", "root", "", "letsgotobasa");
if($connect->connect_error){
	echo 'gagal';
}

?>