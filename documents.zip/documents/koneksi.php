<?php 
$koneksi = new mysqli("localhost", "root", "", "kepalmedia");
$base_url='http://localhost:8888/documents/';
?>