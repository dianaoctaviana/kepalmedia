<?php 
    // mengaktifkan session pada php
    session_start();

    // menghubungkan php dengan koneksi database
    include 'koneksi.php';

    // menangkap data yang dikirim dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];
    $salt = "TWP8G8O3AosvQpgc";
    $hashedPassword = hash('sha256', $password . $salt);

    // menyeleksi data user dengan username dan password yang sesuai
    $result = mysqli_query($koneksi, "SELECT * FROM admin WHERE username = '$username' AND password = '$hashedPassword'");
  
    // menghitung jumlah data yang ditemukan
    $rows = mysqli_num_rows($result);

    // cek apakah username dan password di temukan pada database
    if ($rows > 0) {
        $data = mysqli_fetch_assoc($result);
        // cek jika user login sebagai admin
        if ($data['level'] == "admin"){
            // buat session login
            $_SESSION['username'] = $username;
            $_SESSION['level'] = "admin";
            // alihkan ke halaman dashboard admin
            header("location:index.php");
        // cek jika user login sebagai pengunjung
        } else {
            // buat session login
            $_SESSION['username'] = $username;
            $_SESSION['level'] = "user";
            // alihkan ke halaman dashboard pengunjung
            header("location: indexdua.php");
        }  
    } else {
        // alihkan ke halaman login kembali
        header("location:login.php");
    }
?>