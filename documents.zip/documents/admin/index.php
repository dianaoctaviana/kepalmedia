<?php
session_start();
$koneksi = new mysqli("localhost","root","","kepalmedia");
?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kepal Media</title>
	
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alex+Brush" rel="stylesheet">
    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/aos.css">
    <link rel="stylesheet" href="../css/ionicons.min.css">
    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">
    <link rel="stylesheet" href="../fa/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css"> 
    <link rel="stylesheet" href="../css/display.css">
  <link rel="stylesheet" type="text/css" href="adm/plugin/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="adm/css/admin.css">
  <link rel="stylesheet" type="text/css" href="../css/admin.css">

<style type="text/css">
  .navbar-dark{
    background-color: ;
    height : 80px;
  }
  #customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color:#FE7F9C;
  color: white;
}

.dropdown-menu{
    background-color:#FE7F9C;
    color: white;
    
    width: 100px;

  }
  .dropdown-item{
    color: white;
  }
  .nav-link{
    color: white;
  }
  .navbar-dark{
    background-color: #FE7F9C;
  }

</style>

</head>

<header class="py-9 navbar-dark">
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="../anj.png" height="50" class="d-inline-block"></a>
      <div class="collapse navbar-collapse" id="navbarResponsive">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item active">
                    <a class="nav-link" href="index.php?halaman=home">Home</span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="index.php?halaman=produk">Buku</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="index.php?halaman=pembelian">Pembelian</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="index.php?halaman=pelanggan">User</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="index.php?halaman=logout">Logout</a>
                  </li>
                  
                </ul>
              </div>
            </div>
          </div>
              </nav>
    </header>


<body>
                  <br>
                  <br>

                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  <br>
                  
                  <br>
                  <br>
                  <br>
                
                </ul>
               
            </div>
            
        <div class="col-xs-10" " >
<?php
if (isset($_GET['halaman']))
{
	if ($_GET['halaman'] == "produk")
	{
		include 'produk.php';
	}
	else if($_GET['halaman'] == "pembelian")
	{
		include 'pembelian.php';
	}
  else if($_GET['halaman'] == "destinasi")
  {
    include 'destinasi.php';
  }
  else if($_GET['halaman'] == "transportasi")
  {
    include 'transportasi.php';
  }
	else if($_GET['halaman'] == "pelanggan")
	{
		include 'pelanggan.php';
	}
	else if($_GET['halaman'] == "detail")
	{
		include 'detail.php';
	}
	else if($_GET['halaman'] == "tambahproduk")
	{
		include 'tambahproduk.php';
	}
	else if($_GET['halaman'] == "hapusproduk")
	{
		include 'hapusproduk.php';
	}
	else if($_GET['halaman'] == "logout")
	{
		include 'logout.php';
	}
  else if($_GET['halaman'] == "kuliner")
  {
    include 'kuliner.php';
  }
  else if($_GET['halaman'] == "tambahkuliner")
  {
    include 'tambahkuliner.php';
  }
	 else if($_GET['halaman'] == "hapuskuliner")
  {
    include 'hapuskuliner.php';
  }
  else if($_GET['halaman'] == "souvenir")
  {
    include 'souvenir.php';
  }
  else if($_GET['halaman'] == "tambahdestinasi")
  {
    include 'tambahdestinasi.php';
  }
  else if($_GET['halaman'] == "tambahsouvenir")
  {
    include 'tambahsouvenir.php';
  }
   else if($_GET['halaman'] == "hapussouvenir")
  {
    include 'hapussouvenir.php';
  }
  
   else if($_GET['halaman'] == "tambahtransportasi")
  {
    include 'tambahtransportasi.php';
  }
  else if($_GET['halaman'] == "hapustransportasi")
  {
    include 'hapustransportasi.php';
  }
   else if($_GET['halaman'] == "pembookingan")
  {
    include 'pembookingan.php';
  }
   else if($_GET['halaman'] == "konfirmasi")
  {
    include 'konfirmasi.php';
  }
   else if($_GET['halaman'] == "hapusdestinasi")
  {
    include 'hapusdestinasi.php';
  }
   else if($_GET['halaman'] == "ubahkuliner")
  {
    include 'ubahkuliner.php';
  }
  else if($_GET['halaman'] == "ubahdestinasi")
  {
    include 'ubahdestinasi.php';
  } 
  else if($_GET['halaman'] == "ubahtransportasi")
  {
    include 'ubahtransportasi.php';
  }
  else if($_GET['halaman'] == "ubahproduk")
  {
    include 'ubahproduk.php';
  }
   else if($_GET['halaman'] == "pembayaran")
  {
    include 'pembayaran.php';
  }
   else if($_GET['halaman'] == "detailpembayaran")
  {
    include 'detailpembayaran.php';
  }
   
   


	}
else{
	include 'home.php';
}
?>

<br>
<br>
<br>

              
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

    <script type="text/javascript" src="adm/plugin/Javascript/jquery.min.js"></script>
<script type="text/javascript" src="adm/plugin/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript">
    
   
</body>
</html>





