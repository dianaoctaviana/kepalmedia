<!DOCTYPE html>
<head>
	<title>Ubah Produk</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

	<style type="text/css">
		* {
			margin: auto;
			background-color: #fec5e5;

		}
		form {
			padding-bottom: 100px;
			padding-left:200px;
			padding-right: 200px;
			padding-top: 100px;
		}

	</style>
</head>
<body>

<?php 

$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$_GET[id]'"); 
$pecah = $ambil -> fetch_assoc();



?>
<form method="post" enctype="multipart/form-data">
	<h2>Ubah Produk</h2>

	<div class="form-group">
		<label>Nama</label>
		<input type="text" name="nama" class="form-control" value="<?php echo $pecah['nama_produk']  ?>">
	</div>


	<div class="form-group">
		<label>Harga</label>
		<input type="number" name="harga" class="form-control" value="<?php echo $pecah['harga_produk']  ?>">
	</div>	

	<div class="form-group">
		<img src="../foto_produk/<?php echo $pecah['foto_produk'];?>" width="200">
	</div>

	<div class="form-grpup">
		<label>Ganti foto</label>
		<input type="file" name="foto" class="form-control">
	</div>


	<div class="form-group">
		<label>Deskripsi</label>
		<textarea name="deskripsi" class="form-control" rows="5"><?php echo $pecah['deskripsi_produk'] ?></textarea>
	</div>

	<div class="form-group">
		<label>Stok</label>
		<input type="text" name="stok" class="form-control" value="<?php echo $pecah['stok_produk']  ?>">
	</div>

	<button class="btn btn-primary" name="ubah">Ubah </button>

</form>

<?php 
if (isset($_POST['ubah']))
{
	$namafoto = $_FILES['foto']['name'];
	$lokasifoto = $_FILES['foto']['tmp_name'];
	if (!empty($lokasifoto)) 
	{
		move_uploaded_file($lokasifoto, "../foto_produk/$namafoto");

		$koneksi -> query("UPDATE produk SET nama_produk = '$_POST[nama]',harga_produk = '$_POST[harga]', foto_produk = '$namafoto',deskripsi_produk = '$_POST[deskripsi]' , stok_produk = '$_POST[stok]'     WHERE id_produk='$_GET[id]'");
	}
	else{
		$koneksi -> query("UPDATE produk SET nama_produk = '$_POST[nama]',harga_produk = '$_POST[harga]',deskripsi_produk = '$_POST[deskripsi]' , stok_produk = '$_POST[stok]'     WHERE id_produk='$_GET[id]'");
	}

	echo "<script>location='index.php?halaman=produk';</script>";
} 
?>
</body>

</html>