<head>
	<title>Tambah Souvenir</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

	<style type="text/css">
		* {
			margin: auto;
			background-color: #fec5e5;

		}
		form {
			padding-bottom: 100px;
			padding-left:200px;
			padding-right: 200px;
			padding-top: 100px;
		}

	</style>
</head>


<form method="post" enctype="multipart/form-data">
	<h2>Tambah Souvenir</h2>

	<div class="form-group">
		<label>Nama</label>
		<input type="text" class="form-control" name="namaTempat">
	</div>
	<div class="form-group">
		<label>Alamat</label>
		<input type="text" class="form-control" name="alamat">
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea class="form-control" name="deskripsi" rows="5"></textarea>
	</div>
	<div class="form-group">
		<label>Foto</label>
		<input type="file" class="form-control" name="foto">
	</div>
	<div class="form-group">
		<label>Buka</label>
		<input type="text" class="form-control" name="buka">
	</div>
	<div class="form-group">
		<label>Map</label>
		<input type="text" class="form-control" name="map">
	</div>
	<button class="btn btn-primary" name="save">Simpan</button>

</form>
<?php
if (isset($_POST['save'])) 
{
	$nama = $_FILES['fotosouvenir']['name'];
	$lokasi = $_FILES['fotosouvenir']['tmp_name'];
	move_uploaded_file($lokasi, "../fotosouvenir/".$nama);
	$koneksi->query("INSERT INTO souvenir (namaTempat,alamat,deskripsi,fotosouvenir,buka)
		VALUES('$_POST[namaTempat]','$_POST[alamat]','$_POST[deskripsi]','$nama', '$_POST[buka]', '$nama', '$_POST[map]')");

	echo "<div class='alert alert-info'>Data tersimpan</div>";
	echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=souvenir'>";
}
?>