<?php
session_start();

include 'koneksi.php';

?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <title>KepalMedia</title>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alex+Brush" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="fa/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css"> 
    <link rel="stylesheet" href="css/display.css"> 
</head>

  <body>
    <?php include 'menu.php'; ?>
    <br>
    <br>
<br>

<div class="container ftco-animate">
      <h2 class="mt-4 mb-3">Daftar Produk
      </h2>

      <div class="topnav" align="right">
       
       <form action="" method="post">
        <div class="search-container">
        <input type="text" name="inputan_pencarian" placeholder="Search..." />
            <button type="submit" name="cari"><i class="fa fa-search"></i></button>
      </form>
</div>
</div>
<br>
     
       <div class="row">
  <?php 
        $inputan_pencarian = @$_POST['inputan_pencarian'];
       
        if (isset($_POST["cari"])) {
          if ($inputan_pencarian != "") {
          
        $ambil = $koneksi->query("SELECT * FROM produk WHERE nama_produk LIKE '%$inputan_pencarian%'");
      }else {
        $ambil = $koneksi->query("SELECT * FROM produk");
      
      }
        } else {
          $ambil = $koneksi->query("SELECT * FROM produk");
        
        }
        $cek = mysqli_num_rows($ambil);
        if ($cek < 1){
          ?>
          <tr>
            <td><h2>Maaf, buku tidak ditemukan</h2></td>
          </tr>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          
          <?php 
        } else{
         while($perproduk = $ambil->fetch_assoc())  {  ?>
        
        
        <div class="col-lg-4 col-sm-6 portfolio-item ftco-animate" style="padding-top: 15px">
          <div class="card h-100 ftco-animate" >
            <img class="card-img-top" height="200" src="foto_produk/<?php echo $perproduk['foto_produk']; ?>" alt="" ></a>
            <div class="card-body">
              <h3 class="card-title">
                <center><a><?php echo $perproduk['nama_produk'];?></a></h3>
               <div class="two">
                    <center><h6><span class="price" style="color: black">Rp.<?php echo number_format($perproduk['harga_produk']) ;?></span></h6>
                  
              <center><a href="beli.php?id=<?php echo $perproduk['id_produk']; ?>" class="btn btn-success">Beli</a>
              <a href="detailsouvenir.php?id=<?php echo $perproduk['id_produk']; ?>" class="btn btn-info">Detail</a>
            </div>
            </div>
          </div>
        </div>
        <?php 
      }
    }
       ?>


      </div>
<br>
<br>
<br>
    </div>
    
    <footer class="py-10 navbar-dark">
      <div class="container">
        <p class="m-0 text-center text-white">KepalMedia</p>
      </div>

    </footer>

    
   <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

  </body>

</html>


<?php
?>
